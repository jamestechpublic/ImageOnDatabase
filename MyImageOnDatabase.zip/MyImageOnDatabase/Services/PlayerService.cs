﻿using Microsoft.EntityFrameworkCore;
using MyImageOnDatabase.Data;
using MyImageOnDatabase.Models;

namespace MyImageOnDatabase.Services
{
    public class PlayerService : IPlayerService
    {
        readonly MyDataContext _context;
        public PlayerService(MyDataContext context)
        { 
            _context = context;
        }

        public async Task<List<PlayerType>> GetAllPlayerTypes()
        {
            var result = await _context.PlayerTypes.ToListAsync();
            return result;
        }

        public async Task<List<Player>> GetAllPlayers()
        {
            var result = await _context.Players.Include(p => p.PlayerType).ToListAsync();
            return result;
        }

        public async Task<Player?> GetPlayer(int id)
        {
            var result = _context.Players.Include(p => p.PlayerType).FirstOrDefault(p => p.Id == id);
            return result;
        }

        public async Task AddPlayer(Player player)
        {
            _context.Players.Add(player);
            _context.SaveChanges();
        }

        public async Task UpdatePlayer(int id, Player player)
        {
            var playerToUpdate = await _context.Players.FirstOrDefaultAsync(x => x.Id == id);
            if (playerToUpdate != null)
            {
                playerToUpdate.PlayerName = player.PlayerName;
                playerToUpdate.PlayerImage = player.PlayerImage;
                playerToUpdate.PlayerTypeId = player.PlayerTypeId;

                _context.SaveChanges();
            }
        }

        public async Task DeletePlayer(Player player)
        {
            _context.Players.Remove(player);
            _context.SaveChanges();
        }

        public bool PlayerExists(int id)
        {
            var result = _context.Players.Any(x => x.Id == id);
            
            return result;
        }
    }
}
