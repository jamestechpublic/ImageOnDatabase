﻿using MyImageOnDatabase.Models;

namespace MyImageOnDatabase.Services
{
    public interface IPlayerService
    {
        Task<List<PlayerType>> GetAllPlayerTypes();
        Task<List<Player>> GetAllPlayers();
        Task<Player?> GetPlayer(int id);
        Task AddPlayer(Player player);
        Task UpdatePlayer(int id, Player player);
        Task DeletePlayer(Player player);
        bool PlayerExists(int id);
    }
}
