﻿namespace MyImageOnDatabase.Models
{
    public class PlayerType
    {
        public int Id { get; set; }
        public string TypeName { get; set; }

        public List<Player> Players { get; set; }
    }
}
