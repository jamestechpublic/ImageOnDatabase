﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using MyImageOnDatabase.Models;

namespace MyImageOnDatabase.Data
{
    public class MyDataContext : DbContext
    {
        public MyDataContext (DbContextOptions<MyDataContext> options)
            : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Player>()
                .HasOne(p => p.PlayerType)
                .WithMany(pt => pt.Players)
                .HasForeignKey(p => p.PlayerTypeId);

            base.OnModelCreating(modelBuilder);
        }

        public DbSet<Player> Players { get; set; } = default!;
        public DbSet<PlayerType> PlayerTypes { get; set; } = default!;
    }
}
